A library that provides cryptographic and general-purpose functions for Go
Secure Systems Lab projects at NYU.
