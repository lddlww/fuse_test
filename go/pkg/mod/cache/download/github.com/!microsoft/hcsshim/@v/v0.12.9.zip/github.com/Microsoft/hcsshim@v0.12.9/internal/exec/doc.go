// Package exec implements a minimalized external process launcher. It exists to work around some shortcomings for
// Windows scenarios that aren't exposed via the os/exec package.
package exec
