// Package transport defines the interfaces describing a connection-like data
// transport mechanism.
package transport
