// Package layers deals with container layer mounting/unmounting for LCOW and WCOW
package layers
