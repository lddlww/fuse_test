// Package credentials holds the necessary structs and functions for adding
// and removing Container Credential Guard instances (shortened to CCG
// normally) for V2 HCS schema containers.
package credentials
