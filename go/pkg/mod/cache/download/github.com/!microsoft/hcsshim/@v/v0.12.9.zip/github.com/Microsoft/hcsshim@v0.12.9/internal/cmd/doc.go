// Package cmd provides functionality used to execute commands inside of containers
// or UVMs, and to connect an upstream client to those commands for handling in/out/err IO.
package cmd
