// Package runc defines an implementation of the Runtime interface which uses
// runC as the container runtime.
package runc
