// Package bridge defines the bridge struct, which implements the control loop
// and functions of the GCS's bridge client.
package bridge
