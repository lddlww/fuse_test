package hcserror
