// Package runtime defines the interface between the GCS and an OCI container
// runtime.
package runtime
