package mpb

// make syncWidth func public in test
var SyncWidth = syncWidth

type PriorityQueue = priorityQueue
