OSTree-Go
=========

Go bindings for OSTree. Find out more about OSTree [here](https://github.com/ostreedev/ostree)
