Below are list of adopters of the `ocicrypt` library or supports use of OCI encrypted images:
- [skopeo](https://github.com/containers/skopeo)
- [buildah](https://github.com/containers/buildah)
- [containerd](https://github.com/containerd/imgcrypt)
- [nerdctl](https://github.com/containerd/nerdctl)
- [distribution](https://github.com/distribution/distribution)

Below are the list of projects that are in the process of adopting support:
- [quay](https://github.com/quay/quay)
- [kata-containers](https://github.com/kata-containers/kata-containers)
