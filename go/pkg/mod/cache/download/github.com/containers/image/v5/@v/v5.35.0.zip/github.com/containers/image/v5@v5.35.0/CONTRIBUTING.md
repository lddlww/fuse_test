# Contributing to Containers/Image

We'd love to have you join the community! [Learn how to contribute](https://github.com/containers/common/blob/main/CONTRIBUTING.md) to the Containers Group Projects.

Please note that this information cannot be relevant to this project:

- We don’t typically require 2 LGTMs — few people are watching the repo
- There is no OWNERS file — it’s targeted at bots that are not active in the repo
