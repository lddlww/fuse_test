####> This option file is used in:
####>   podman create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--cidfile**=*file*

Write the container ID to *file*.  The file is removed along with the container, except
when used with podman --remote run on detached containers.
