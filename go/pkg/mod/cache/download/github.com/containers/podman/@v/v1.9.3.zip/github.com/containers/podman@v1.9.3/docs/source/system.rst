System
======

:doc:`df <markdown/podman-system-df.1>` Show podman disk usage

:doc:`info <markdown/podman-info.1>` Display podman system information

:doc:`migrate <markdown/podman-system-migrate.1>` Migrate containers

:doc:`prune <markdown/podman-system-prune.1>` Remove unused data

:doc:`renumber <markdown/podman-system-renumber.1>` Migrate lock numbers
