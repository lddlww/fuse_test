####> This option file is used in:
####>   podman build, farm build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--dns-option**=*option*

Set custom DNS options to be used during the build.
