Volume
======
:doc:`create <markdown/podman-volume-create.1>` Create a new volume

:doc:`inspect <markdown/podman-volume-inspect.1>` Display detailed information on one or more volumes

:doc:`ls <markdown/podman-volume-ls.1>` List volumes

:doc:`prune <markdown/podman-volume-prune.1>` Remove all unused volumes

:doc:`rm <markdown/podman-volume-rm.1>` Remove one or more volumes
