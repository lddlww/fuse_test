####> This option file is used in:
####>   podman push, save
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--compress**

Compress tarball image layers when pushing to a directory using the 'dir' transport. (default is same compression type, compressed or uncompressed, as source)
