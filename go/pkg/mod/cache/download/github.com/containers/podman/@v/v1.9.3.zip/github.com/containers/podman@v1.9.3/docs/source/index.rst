.. Podman documentation master file, created by
   sphinx-quickstart on Tue Oct 22 15:20:30 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Podman's documentation!
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Introduction
   Commands
   Reference
   Tutorials




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
