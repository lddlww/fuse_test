![PODMAN logo](../../logo/podman-logo-source.svg)

A standard container image for lint-checking and validating changes to the libpod
repository.  The
[contributors guide contains the documentation for usage.](https://github.com/containers/libpod/blob/master/CONTRIBUTING.md#go-format-and-lint).  Note that this container image is also utilized
in automation, see the file [.cirrus.yml](.cirrus.yml)
