####> This option file is used in:
####>   podman container clone, pod clone
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--destroy**

Remove the original <<container|pod>> that we are cloning once used to mimic the configuration.
