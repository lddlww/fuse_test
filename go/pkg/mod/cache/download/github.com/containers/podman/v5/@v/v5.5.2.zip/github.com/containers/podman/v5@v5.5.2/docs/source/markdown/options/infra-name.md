####> This option file is used in:
####>   podman pod clone, pod create
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--infra-name**=*name*

The name that is used for the pod's infra container.
