Play
====

:doc:`kube <markdown/podman-play-kube.1>` Play a pod based on Kubernetes YAML
