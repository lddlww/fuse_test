// +build !varlink

package main

import "github.com/spf13/cobra"

var (
	// nolint:varcheck,deadcode,unused
	_varlinkCommand = &cobra.Command{
		Use: "",
	}
)
