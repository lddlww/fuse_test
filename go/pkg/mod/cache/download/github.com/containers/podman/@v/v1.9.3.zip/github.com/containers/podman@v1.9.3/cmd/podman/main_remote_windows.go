// +build remoteclient,windows

package main

func setSyslog() error {
	return nil
}
