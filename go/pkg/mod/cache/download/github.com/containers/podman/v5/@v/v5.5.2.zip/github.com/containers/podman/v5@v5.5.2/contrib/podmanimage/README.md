The podman container image build context and automation have been
moved to [https://github.com/containers/image_build/tree/main/podman](https://github.com/containers/image_build/tree/main/podman)
