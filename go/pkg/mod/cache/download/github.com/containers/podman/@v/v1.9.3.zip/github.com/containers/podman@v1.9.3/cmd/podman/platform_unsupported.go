// +build !linux

package main

func CheckForRegistries() {
}
