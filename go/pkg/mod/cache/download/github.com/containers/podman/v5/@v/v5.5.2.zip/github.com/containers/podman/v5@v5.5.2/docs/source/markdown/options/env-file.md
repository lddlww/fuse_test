####> This option file is used in:
####>   podman create, exec, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--env-file**=*file*

Read in a line-delimited file of environment variables.
