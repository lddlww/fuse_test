####> This option file is used in:
####>   podman login, logout
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--compat-auth-file**=*path*

Instead of updating the default credentials file, update the one at *path*, and use a Docker-compatible format.
