####> This option file is used in:
####>   podman build, farm build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--force-rm**

Always remove intermediate containers after a build, even if the build fails (default true).
