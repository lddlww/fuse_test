package common

var DefaultKernelNamespaces = "cgroup,ipc,net,uts"
