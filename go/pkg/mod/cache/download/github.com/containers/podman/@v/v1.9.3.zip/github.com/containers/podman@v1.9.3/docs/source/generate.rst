Generate
========

:doc:`kube <markdown/podman-generate-kube.1>` Generate Kubernetes pod YAML from a container or pod

:doc:`systemd <markdown/podman-generate-systemd.1>` Generate a systemd unit file for a Podman container
