package docs

//go:generate go run varlink/apidoc.go ../pkg/varlink/io.podman.varlink ../API.md
