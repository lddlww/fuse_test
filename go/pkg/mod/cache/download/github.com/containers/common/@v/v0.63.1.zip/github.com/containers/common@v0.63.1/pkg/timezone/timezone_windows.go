package timezone

func ConfigureContainerTimeZone(timezone, containerRunDir, mountPoint, etcPath, containerID string) (string, error) {
	return "", nil
}
