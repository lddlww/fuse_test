package hooks

// version a structure for checking the version of a hook configuration.
type version struct {
	Version string `json:"version"`
}
