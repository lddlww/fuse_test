SysInfo stores information about which features a kernel supports.
