package dummy

import (
	"testing"
)

func TestDummy(_ *testing.T) {
}
