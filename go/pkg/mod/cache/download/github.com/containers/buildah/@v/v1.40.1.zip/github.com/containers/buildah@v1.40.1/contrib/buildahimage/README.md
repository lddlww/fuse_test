The buildah container image build context and automation have been
moved to [https://github.com/containers/image_build/tree/main/buildah](https://github.com/containers/image_build/tree/main/buildah)
