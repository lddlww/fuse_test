//go:build !linux || !cgo

package btrfs
