## containers-storage-containers 1 "August 2016"

## NAME
containers-storage containers - List known containers

## SYNOPSIS
**containers-storage** **containers**

## DESCRIPTION
Retrieves information about all known containers and lists their IDs and names.

## EXAMPLE
**containers-storage containers**

## SEE ALSO
containers-storage-container(1)
