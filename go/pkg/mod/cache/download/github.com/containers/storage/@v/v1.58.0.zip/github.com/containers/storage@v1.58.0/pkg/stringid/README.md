This package provides helper functions for dealing with string identifiers
