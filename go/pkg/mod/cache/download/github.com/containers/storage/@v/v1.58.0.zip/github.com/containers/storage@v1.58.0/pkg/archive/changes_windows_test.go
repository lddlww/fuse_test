package archive

func resetSymlinkTimes(path string) error {
	return nil
}
