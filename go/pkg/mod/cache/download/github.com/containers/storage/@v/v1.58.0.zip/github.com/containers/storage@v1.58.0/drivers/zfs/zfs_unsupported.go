//go:build !linux && !freebsd

package zfs
