This package provides helper functions for dealing with strings
