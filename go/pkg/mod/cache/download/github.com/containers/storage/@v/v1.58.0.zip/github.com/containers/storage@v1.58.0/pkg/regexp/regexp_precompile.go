//go:build regexp_precompile

package regexp

const precompile = true
