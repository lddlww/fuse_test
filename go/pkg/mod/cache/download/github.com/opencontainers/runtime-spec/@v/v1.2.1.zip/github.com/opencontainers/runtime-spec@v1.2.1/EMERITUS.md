# Emeritus

We would like to acknowledge previous OCI runtime spec maintainers and their huge contributions to our collective success:

- Rohit Jnagal (@rjnagal)
- Victor Marmol (@vmarmol)
- Alexander Morozov (@LK4D4)
- Vishnu Kannan (@vishh)
- Brandon Philips (@philips)
- Vincent Batts (@vbatts)

We thank these members for their service to the OCI community.
