//go:build !linux

package capabilities
