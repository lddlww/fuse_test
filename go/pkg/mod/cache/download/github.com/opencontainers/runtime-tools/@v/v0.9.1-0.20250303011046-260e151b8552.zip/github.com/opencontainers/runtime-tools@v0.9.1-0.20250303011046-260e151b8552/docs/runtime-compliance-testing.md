# Runtime compliance testing

## Supported APIs

In order to be tested for [compliance][], runtimes MUST support at least one of the following APIs:

* Version 1.0.1 of the [OCI Runtime Command Line Interface](command-line-interface.md).

[compliance]: https://github.com/opencontainers/runtime-spec/blob/v1.0.0-rc4/spec.md#notational-conventions
