# testdata

This key is cribbed from [here](https://github.com/golang/oauth2/blob/d668ce993890a79bda886613ee587a69dd5da7a6/google/testdata/gcloud/credentials).
It's invalid but parses sufficiently to test `NewEnvAuthenticator`.
