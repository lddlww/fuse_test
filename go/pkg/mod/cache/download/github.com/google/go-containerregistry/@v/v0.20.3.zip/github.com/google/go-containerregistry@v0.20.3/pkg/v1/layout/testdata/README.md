# Where did this data come from?

These were manually produced from the pkg/v1/tarball/testadata tarballs.

TODO: Make this reproducible. There's not currently an easy way to do this.
