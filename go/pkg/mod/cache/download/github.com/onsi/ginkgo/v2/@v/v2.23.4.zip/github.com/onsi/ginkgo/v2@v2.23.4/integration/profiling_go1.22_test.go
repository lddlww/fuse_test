//go:build go1.22

package integration_test

// lockContestPrefix is the function name prefix with Go 1.22 and later
const lockContestPrefix = "lock_contest_test.init."
