package tags_test

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("TagsTests", func() {
	It("should have a test", func() {

	})
})
