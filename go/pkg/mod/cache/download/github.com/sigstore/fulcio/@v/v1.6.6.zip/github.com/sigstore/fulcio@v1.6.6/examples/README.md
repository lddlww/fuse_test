fulcio examples
===============

This directory contains example code that shows how one utilize the fulcio
library for certificate generation.

# request-certificate
This code is a minimal example how one would request a short-lived certificate
(20 minutes) for code signing. It uses the fulcio oauth portal and generates a
RSA 4096 key.
