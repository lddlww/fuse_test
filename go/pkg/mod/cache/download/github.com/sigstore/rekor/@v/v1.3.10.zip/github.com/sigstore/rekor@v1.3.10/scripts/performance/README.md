Performance Scripts
===================

This directory is a collection of scripts for exercising rekor's performance.
