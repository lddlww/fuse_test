# Bridge

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/bridge)](https://pkg.go.dev/go.opentelemetry.io/otel/bridge)
