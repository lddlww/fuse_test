// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package attribute provides key and value attributes.
package attribute // import "go.opentelemetry.io/otel/attribute"
